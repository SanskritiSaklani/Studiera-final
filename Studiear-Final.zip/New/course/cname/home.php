
<?php
session_start();

	$con=mysqli_connect('localhost','root');
	mysqli_select_db($con,'New');
    $course_name=$_GET['course_name'];
	
		//$id=$_POST['txt1'];
		$q="select * from course where 'course_name'=$course_name;";
		$result=mysqli_query($con,$q);
		$res=mysqli_fetch_array($result); 

	?>
      <div class="card col-md-6">
           <?php $_SESSION['message'] =  "<h1>Welcome! </h1>";
            header("location:java_programming.php?course_name=".$res['course_name']); ?>


      </div>