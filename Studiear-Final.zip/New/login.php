<?php
session_start();
	include('connection.php');
	include('functions.php');
	
	function check_input($data) {
		$data = trim($data);
		$data = stripslashes($data);
		$data = htmlspecialchars($data);
		return $data;
	}
	
	
		if($_SERVER["REQUEST_METHOD"] == "POST")
	{
		//something was posted
		$emailid = check_input($_POST['Emailid']);
		$password = check_input($_POST['Password']);

        if (!preg_match("/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/",$emailid)) {

			echo"<script>
			window.alert('Please provide a valid email address');
			window.location.href='index.php';
		    </script>";
		
				//$_SESSION['msg'] = "Please provide a valid email address"; 			
				//header('location: index.php');}
		}
		else{

		$femailid = $emailid;	
        $fpassword=md5($password);
		//$query = "SELECT * FROM `user` WHERE Emailid = '$femailid' and Password ='$fpassword'";
		//$query = "SELECT * FROM `user` WHERE Emailid = '$emailid' && Password ='$fpassword' ";
	    //$result = mysqli_query($conn,"select * from `user` where Emailid='$femailid' '");	   


		$query="select * from `user` where Emailid ='$femailid'and Password ='$password'  ";
		$result = mysqli_query($conn,$query);
		$row = mysqli_fetch_assoc($result);
		$count = mysqli_num_rows($result);

			if($count == 1){
				

			if ($row['access']==1){
				$_SESSION['id']=$row['userid'];
				
				?>
				<script>
					window.alert('Login Success, Welcome Admin!');
					window.location.href='admin/admin_main.php';
				</script>";
				<?php
			}
			else{
				$_SESSION['id']=$row['userid'];
				?>
				<script>
					window.alert('Login Success, Welcome User!');
					window.location.href='userdemo.php';
				</script>
				<?php
			
		}}
	
		else{
			
				echo"<script>
					window.alert('Login Fail,Invalid Input!!');
					window.location.href='index.php';
				</script>";
				
			//    $_SESSION['msg'] = "Login Failed, Invalid Input!";
			//     header('location: index.php');
		}
		
	}

}	
?>