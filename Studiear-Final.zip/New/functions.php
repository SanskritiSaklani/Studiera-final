<?php

function check_login($conn)          //check if user is login
{

	if(isset($_SESSION['uid']))      //checking if inside user session there is an id(chceking session value exits)
	{

		$id = $_SESSION['uid'];
		$query = "select * from user where uid = '$uid' limit 1";

		$result = mysqli_query($conn,$query);    //read from database
		if($result && mysqli_num_rows($result) > 0)       //result is +ve and no of rows>0
		{

			$user_data = mysqli_fetch_assoc($result);      //assoc=associative array
			return $user_data;
		}
	}

	//redirect to in
	header("Location: index.php");
	die;

}

function random_num($length)                   //creating random values for user_id
{

	$text = "";
	if($length < 5)
	{
		$length = 5;
	}

	$len = rand(4,$length);        //getting no btw 4 and leng

	for ($i=0; $i < $len; $i++) {        //to get diff length of user_id
		
		$text .= rand(0,9);
	}

	return $text;
}