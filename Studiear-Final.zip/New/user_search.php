<?php 
	 session_start();
	 if (!isset($_SESSION['id'])) 
	 {
		header('location:index.php');
		exit();
		}

 ?>

<!DOCTYPE html>
<html>
<head>
	<title>Studiera</title>
	<!----css file link-->
	<link rel="stylesheet" type="text/css" href="css/programming.css">

	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

	<!-- jQuery library -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<!-- Latest compiled JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>


	<!----Linking google fonts-->
	<link href="https://fonts.googleapis.com/css?family=Lobster" rel="stylesheet">

	<!----font-awsome start-->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

	<style type="text/css">
		.context-dark, .bg-gray-dark, .bg-primary {
    color: rgba(255, 255, 255, 0.8);
}

.footer-classic a, .footer-classic a:focus, .footer-classic a:active {
    color: #ffffff;
}
.nav-list li {
    padding-top: 5px;
    padding-bottom: 5px;
}

.nav-list li a:hover:before {
    margin-left: 0;
    opacity: 1;
    visibility: visible;
}

ul, ol {
    list-style: none;
    padding: 0;
    margin: 0;
}

.social-inner {
    display: flex;
    flex-direction: column;
    align-items: center;
    width: 100%;
    padding: 23px;
    font: 900 13px/1 "Lato", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
    text-transform: uppercase;
    color: rgba(255, 255, 255, 0.5);
}
.social-container .col {
    border: 1px solid rgba(255, 255, 255, 0.1);
    display: inline-block; 
}
.nav-list li a:before {
    content: "\f14f";
    font: 400 21px/1 "Material Design Icons";
    color: #4d6de6;
    display: inline-block;
    vertical-align: baseline;
    margin-left: -28px;
    margin-right: 7px;
    opacity: 0;
    visibility: hidden;
    transition: .22s ease;
}



.div1                           /* for title image*/
{
	margin-top: 10%;
   position: relative;
    height: 500px;
    width: 1263px;
    /* background:url(uploadimg/programming_image.png);
} */
}


	</style>



</head>
<body>


			<!---Navigation Starts	----->

	
	<nav class="navbar navbar-inverse navbar-fixed-top">
		<div class="container">
			<div class="navbar-header">
				<!------Responsive Button---->
				

				<h1 style="color: white;margin-top: 10px;">Studiera</h1>
			</div>
			<div class="collapse navbar-collapse" id="navi">
                 <!------Navigation menus starts---->
				<ul class="nav navbar-nav navbar-right">
					
			<li>	<form class="form-inline my-2 my-lg-0" method="GET" action="user_search.php">
                <input class="form-control mr-sm-2" type="search" name="search" placeholder="Search your course" aria-label="Search" required/>
                <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
               </form></li>
					 <li><a href="logout.php">Log-out</a></li>
				  
					
				</ul>
	                 <!------Navigation menus ends---->
			</div>
		</div>
	</nav>
    <br><br><br><br><br><br><br>
<?php
 include 'connection.php';   
    if(isset( $_GET['search'])){
     $search=mysqli_real_escape_string($conn,$_GET['search']);
     $sql ="SELECT * FROM `courses` WHERE course_name LIKE '%$search%'  ";
     $res = mysqli_query($conn, $sql);
     if(mysqli_num_rows($res)>0){
        echo'  <div class="tab-pane container active" id="home">
        <div class="card-header mt-3 mr-5 bg-white text-info border-0 shadow card1" style="width: 1050px; box-shadow: 1px 1px 1px 1px #ccc"><b>Related Search</b></div>';
           echo'<br><br><br>';
     
           while($row = mysqli_fetch_assoc($res)){
            $name = $row['course_name'];
            $desc = $row['course_desc'];
            $course_id = $row['course_id']; 
            $course_image=$row['course_image'];
           

            
            echo'<div class="col-md-4 col-sm-6 col-xs-12 content-border" style="margin-bottom: 10px;">
            <div class="latest-news-wrap">
                <div class="news-img">
                    <img src="'.$course_image.'" class="img-responsive">
                    <div class="deat">
                        <span>'.$name.'</span>
                    </div>
                </div>

                <div class="news-content">
                    <p>
                        '.$desc.'
                    </p><br>
                    <a href="course/cname/java_programming.php?course_name='.$name.'">Notes</a>
                    <a href="chatroom/claim.php?course_name='.$name.'">Chat</a>
                    <a href="forum/threadlist.php?course_name='.$name.'">Forum</a>
                </div>
            </div>
        </div>';
    }
}
else{
       echo '<div class="jumbotron jumbotron-fluid">
               <div class="container">
                    <p class="display-4">No Results Found</p>
                    <p class="lead">
                     Suggestions:<ul>

                              <li>Check your spelling.</li>
                              <li>  Try more general words.</li>
                              <li> Try different words that mean the same thing.</li>
                            </ul>
                            </p>
                </div>
           </div> ';
       
}
}
?>