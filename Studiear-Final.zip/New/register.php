<?php

	include('connection.php');
	include('functions.php');
	session_start();
	$password_err="";
	$email_err="";
	$email_exist="";
	function check_input($data) {
		$data = trim($data);
		$data = stripslashes($data);
		$data = htmlspecialchars($data);
		return $data;
	}
	
	if ($_SERVER["REQUEST_METHOD"] == "POST") {
		$emailid=check_input($_POST['Emailid']);
		$password = check_input($_POST['Password']);
        $confirmpassword = check_input($_POST['Confirmpassword']);

		if($password != $confirmpassword){  
            $password_err = "Passwords should match";
             ?><script>
			 window.alert('Password Mismatched!');
			</script>;	<?php	
         
        }
		
		if (!preg_match("/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/",$emailid)) {
			$email_err="Provide a valid email address";
			echo'<script>alert("Please provide a valid email address")</script>';
		}

		 $query="SELECT Emailid from `user` where Emailid='$emailid'  ";
		 $result = mysqli_query($conn,$query);
		 $row = mysqli_fetch_assoc($result);
		 $count=mysqli_num_rows($result);
		 if($count==1)
		{
			$email_exist="Email_id already exist";
			echo'<script>alert("Email address already exist")</script>';
		}



		if(empty($email_err) && empty($password_err) && empty($email_exist))   //checking they r empty 
		{
		$name = check_input($_POST['Name']);                         //inside post use same name that is written below inside name=""
        $dob = check_input($_POST['DOB']);
        $gender =check_input($_POST['Gender']);
		$emailid = $_POST['Emailid'];
		$password = $_POST['Password'];
		//$fpassword=md5($Password);
        $confirmpassword =$_POST['Confirmpassword'];
		//$fcpassword=md5($Confirmpassword);
		$access =check_input($_POST['access']);
		


		$uid = random_num(20);
		$query="insert into `user` (Name,DOB,Gender,Emailid,Password,Confirmpassword,uid,access) values ('$name','$dob','$gender','$emailid','$password','$confirmpassword','$uid', '$access')";
		mysqli_query($conn, $query);
		$_SESSION['msg'] = "Sign up successful. You may login now!"; 
		header('location: index.php');
		}
        
		else{


			
			echo"<script>
			window.alert('Something went wrong try again!');
			window.location.href='signup.php';
		     </script>";

	//	$_SESSION['sign_msg'] = "Please provide correct email or password"; 
			//header('location: signup.php');
		}
		
		
	}
?>