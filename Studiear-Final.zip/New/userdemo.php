<?php 
	 session_start();
	 if (!isset($_SESSION['id'])) 
	 {
		header('location:index.php');
		exit();
		}

 ?>

<!DOCTYPE html>
<html>
<head>
	<title>Studiera</title>
	<!----css file link-->
	<link rel="stylesheet" type="text/css" href="css/programming.css">

	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

	<!-- jQuery library -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<!-- Latest compiled JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>


	<!----Linking google fonts-->
	<link href="https://fonts.googleapis.com/css?family=Lobster" rel="stylesheet">

	<!----font-awsome start-->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

	<style type="text/css">
		.context-dark, .bg-gray-dark, .bg-primary {
    color: rgba(255, 255, 255, 0.8);
}

.footer-classic a, .footer-classic a:focus, .footer-classic a:active {
    color: #ffffff;
}
.nav-list li {
    padding-top: 5px;
    padding-bottom: 5px;
}

.nav-list li a:hover:before {
    margin-left: 0;
    opacity: 1;
    visibility: visible;
}

ul, ol {
    list-style: none;
    padding: 0;
    margin: 0;
}

.social-inner {
    display: flex;
    flex-direction: column;
    align-items: center;
    width: 100%;
    padding: 23px;
    font: 900 13px/1 "Lato", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
    text-transform: uppercase;
    color: rgba(255, 255, 255, 0.5);
}
.social-container .col {
    border: 1px solid rgba(255, 255, 255, 0.1);
    display: inline-block; 
}
.nav-list li a:before {
    content: "\f14f";
    font: 400 21px/1 "Material Design Icons";
    color: #4d6de6;
    display: inline-block;
    vertical-align: baseline;
    margin-left: -28px;
    margin-right: 7px;
    opacity: 0;
    visibility: hidden;
    transition: .22s ease;
}



.div1                           /* for title image*/
{
	margin-top: 10%;
   position: relative;
    height: 500px;
    width: 1263px;
    /* background:url(uploadimg/programming_image.png);
} */
}


	</style>



</head>
<body>


			<!---Navigation Starts	----->

	
	<nav class="navbar navbar-inverse navbar-fixed-top">
		<div class="container">
			<div class="navbar-header">
				<!------Responsive Button---->
				

				<h1 style="color: white;margin-top: 10px;">Studiera</h1>
			</div>
			<div class="collapse navbar-collapse" id="navi">
                 <!------Navigation menus starts---->
				<ul class="nav navbar-nav navbar-right">
					
			<li>	<form class="form-inline my-2 my-lg-0" method="GET" action="user_search.php">
                <input class="form-control mr-sm-2" type="search" name="search" placeholder="Search your course" aria-label="Search" required/>
                <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
               </form></li>
					 <li><a href="logout.php">Log-out</a></li>
				  
					
				</ul>
	                 <!------Navigation menus ends---->
			</div>
		</div>
	</nav>
			<!---Navigation Ends	----->

			<!---Login Start------->

			<!-- <div class="modal fade modal-dialog-centered" id="mymodal">
				<div class="modal-dialog ">
					<div class="modal-content">
						<h3 id="login-heading">Login</h3>
						
					<div class="modal-body" >
						<div class="left-box">
						<form method="POST" enctype="multipart/form-data" action="imgdemo.php">
							<div class="form-group">
								<label><i class="fa fa-user fa-2x"></i>Language Name :</label>
								<input type="text" name="languagename" class="form-control">


								<label><i class="fa fa-lock fa-2x"></i>Language Description  :</label>
								<input type="text" name="languagedesc" class="form-control">

								<label><i class="fa fa-lock fa-2x"></i>Language Image :</label>
								<input type="file" name="languageimg" class="form-control">

								<button id="btn-login" type="submit">Add Course</button>
								
							</div>
							<div class="register">
								<h2>Don't have an account?&nbsp<span id="create-account"><a href="signup.html">Create</span></a> </h2>
							</div>
							
						</form>
					</div>
					<div class="right-box">
						<span class="signinwith">Sign in With <br> Social Networks</span>

						<button class="social facebook">Log in with Facebook</button>
						<button class="social twitter">Log in with twitter</button>
						<button class="social google">Log in with gmail</button>
					</div>
						
					</div>
					
						
				</div>
			</div>
		</div>
 -->
         <!---Login Ends------->





<!-- 
<div>
	<img src="C:\Users\sunil\Pictures\wallpaper\be_all.jpg">
</div> -->

<!-- 
<div class="container-fluid  div1">
		
	</div> -->



 			<!---programming languages Section Start	----->
<br><br><br><br><br><br>
 			<section class="latest-news-area" id="latest">
 				<div class="container">
 					<div class="row">
 						<div class="col-xs-12">
 							<div class="section-title text-center">
 								<h2><b>COURSES</b></h2>
 								<div class="sub-heading">
 									Following are the available Courses <br>
 									Start learning today
 								</div>
 							</div>
 						</div>
 					</div>
<br>

 					

<?php


			   // session_start();

			   $con=mysqli_connect('localhost','root');
               mysqli_select_db($con,'New');

			   $q="select * from courses";
			   $query=mysqli_query($con,$q);
			   while ($res=mysqli_fetch_array($query)) {

			?>

			<div class="col-md-4 col-sm-6 col-xs-12 content-border" style="margin-bottom: 10px;">
 								<div class="latest-news-wrap">
 									<div class="news-img">
 										<img src=<?php echo $res['course_image']; ?> class="img-responsive">
 										<div class="deat">
 											<span><?php echo $res['course_name']; ?></span>
 										</div>
 									</div>

 									<div class="news-content">
 										<p>
 											<?php echo $res['course_desc']; ?>
 										</p><br>
 										<a href="course/cname/java_programming.php?course_name=<?php echo $res['course_name'] ?>">Notes</a>
										 <a href="chatroom/claim.php?course_name=<?php echo $res['course_name'] ?>">Chat</a>
										 <a href="forum/threadlist.php?course_name=<?php echo $res['course_name'] ?>">Forum</a>
 									</div>
 								</div>
 							</div>

		

<?php } ?>



 				</div>
 				
 			</section>


 			<!---courses Section ends	----->


 			<!---footer Section Start	----->

<!-- <br><br><br><br>

<footer class="section footer-classic context-dark bg-image" style="background: #2d3246;">
        <div class="container">
          <div class="row row-30">
            <div class="col-md-4 col-xl-5">
              <div class="pr-xl-4"><a class="brand" href="index.html"><img class="brand-logo-light" src="images/agency/logo-inverse-140x37.png" alt="" width="140" height="37" srcset="images/agency/logo-retina-inverse-280x74.png 2x"></a>
                <p>Unique Devloper is an excellent learning hub, dedicated to the programmer who want to explore.</p>
                < Rights-
                <p class="rights"><span>©  </span><span class="copyright-year">2018</span><span> </span><span>UniqueDeveloper</span><span>. </span><span>All Rights Reserved.</span></p>
              </div>
            </div>
            <div class="col-md-4">
              <h5>Contacts</h5>
              <dl class="contact-list">
                <dt>Address:</dt>
                <dd>Nagardas Road, andheri east, mumbai 400101</dd>
              </dl>
              <dl class="contact-list">
                <dt>email:</dt>
                <dd><a href="mailto:#">uniquedeveloper0@gmail.com</a></dd>
              </dl>
              <dl class="contact-list">
                <dt>phones:</dt>
                <dd><a href="tel:#">+91 9082944195</a> <span>or</span> <a href="tel:#">+91 7738364521</a>
                </dd>
              </dl>
            </div>
            <div class="col-md-4 col-xl-3">
              <h5>Links</h5>
              <ul class="nav-list">
                <li><a href="#">About</a></li>
                <li><a href="#">Projects</a></li>
                <li><a href="#">Blog</a></li>
                <li><a href="#">Contacts</a></li>
                <li><a href="#">Pricing</a></li>
              </ul>
            </div>
          </div>
        </div>
        <div class="row no-gutters social-container">
          <div class="col"><a class="social-inner" href="#"><span class="icon mdi mdi-facebook"></span><span>Facebook</span></a></div>
          <div class="col"><a class="social-inner" href="#"><span class="icon mdi mdi-instagram"></span><span>instagram</span></a></div>
          <div class="col"><a class="social-inner" href="#"><span class="icon mdi mdi-twitter"></span><span>twitter</span></a></div>
          <div class="col"><a class="social-inner" href="#"><span class="icon mdi mdi-youtube-play"></span><span>google</span></a></div>
        </div>
      </footer> -->



 			<!---footer Section Ends	----->

			
</body>
</html>