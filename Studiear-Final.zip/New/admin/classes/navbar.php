<!doctype html>
<html>
<head>
<title > </title>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style>
    body {
        /* font-family: cursive; */
        margin: 0px;
        padding: 0px;
        /* background: url('downloads/book2.jpg'); */
        /* background-color:rgb(228, 189, 174); */
       
    }
   
    .left img{
    
        width: 100px;

    }
    .left div{
        text-align: center;
        color: BROWN;
        font-size: 23px;
        line-height: 19px;
       
    }

    .left {
        /* border: 2px solid red; */
        display: inline-block;
        position: absolute;
        top: 25px;
        left: 50px;

    }

    .mid {
        /* border: 5px solid rgb(14, 4, 48); */
        display: block;
        width: 40%;
        margin: 25px auto;
        font-size: 18px;

    }

    .right {
        /* border: 5px solid rgb(23, 185, 36); */
        display: inline-block;
        position: absolute;
        right: 34px;
        top: 25px;
        
    }
    .navbar {
        display: inline-block;
        background-color:rgb(131, 36, 36);
        padding:15px 45px;
        border-radius:20px;
    }

    .navbar li {
        display: inline-block;
        font-style: 20px;
    }

    .navbar li a {
        color: rgb(233, 200, 161);
        text-decoration-line: none;
        padding: 30px 30px;
    }

    .navbar li a:hover,
    .navbar li a.active {
        color: rgb(225, 238, 111);
        text-decoration-line: underline;

    }

    .btn{
        background-color: rgb(131, 36, 36);
        color:rgb(235, 192, 141);
        margin:0px 9px;
        padding:4px 14px;
        border:2px solid rgb(248, 182, 101);
        border-radius: 10px;
        font-size: 20px;
        cursor:pointer;
        /* font-family: cursive; */

    }
    .btn:hover{
        background-color: rgb(90, 53, 7);
    }

    .container{
        color:brown;
        border:2px solid rgb(230, 112, 112);
        border-radius: 20px; 
        padding: 10px;
        width: 30%;
        margin:50px auto;
        display: block;
            }
     .form-group input{
         text-align: center;
         display: inline;
         margin:20px;
         padding:1px 20px;
         border:2px solid burlywood;
         font-size: 15px;
         border-radius: 5px;
         /* font-family: cursive; */
        
     }
     
     .container h1,h3{
         text-align: center;
     }
     .container button{
         display: block;
         width:20%;
         margin:10px auto;
     }
     .container label{
         padding:5px 10px;
     }


</style>
</head>
<body >

    <header class="header">
        
        <!-- leftbox for logo -->
        <div class=left>
          <img src="downloads/book1.jpeg" alt="">
            <div>StudiEra</div>

        </div>

        <!-- midbox for navigation -->
         <div class=mid>
            <ul class="navbar">
                <li><a href="#" class=active>Home</a></li>
                <li><a href="#">About Us</a></li>
                <li><a href="#">Settings</a></li>
                <li><a href="#">Help</a></li>
            </ul>


        </div> 

        <!--rightbox for buttons-->
        <div class=right>
            <button class="btn">Contact-Us </button>
            <!-- <button class="btn">Email-Us</button> -->
        </div> 
        </body>
 </html>