<?php 

session_start();
	 if (!isset($_SESSION['id'])) 
	 {
		header('location:../../index.php');
		exit();
		}
  include("classes/admin.php");
  $admin=new admin;
  $userd=$admin->show_users();

 ?>

<!doctype html>
<html lang="en">
  <head>



 <!-- <link href="../online_quize/admin/bootstrap.min.css" rel="stylesheet"> -->


    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">

    <title>Admin panel</title>


  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>


  <link href="https://fonts.googleapis.com/css?family=Quicksand" rel="stylesheet">
         <!--  font awsome cdn -->
  <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

<style type="text/css">
  
    .sidebar-list
    {
        margin-right: -15px;
        
        font-family: 'Quicksand', sans-serif; 
        font-size: 14px
    }

    .sidebar-list li:hover
    {
      background-color: deepskyblue !important;
    }
     .sidebar-list li a
     {
        color:white;
        text-decoration: none;
     }

     .mytable1 .card
     {
     background: #5f2c82;  /* fallback for old browsers */
background: -webkit-linear-gradient(to right, #49a09d, #5f2c82);  /* Chrome 10-25, Safari 5.1-6 */
background: linear-gradient(to right, #49a09d, #5f2c82); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */

     }

     .mytable2 .card
     {
      background: #EC6F66;  /* fallback for old browsers */
background: -webkit-linear-gradient(to right, #F3A183, #EC6F66);  /* Chrome 10-25, Safari 5.1-6 */
background: linear-gradient(to right, #F3A183, #EC6F66); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */

     }
     .card 
     {
      overflow: hidden;
      transition: all 0.9s ease;
     }
     .card:hover
     {
      transform: scale(1.04);
     }



    

</style>

  </head>

  <body style="background-color:#f1efef">

  <nav class="navbar navbar-expand-lg navbar-light bg-dark fixed-top">
  <a class="navbar-brand text-white" href="#">Studiera</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto ">
      <li class="nav-item active">
        <a class="nav-link text-white" href="#">Home <span class="sr-only">(current)</span></a>
      </li>
    </ul>
    <form class="form-inline my-2 my-lg-0" method="GET" action="admin_search.php">
      <input class="form-control mr-sm-2" type="search" name="search" placeholder="Search your course" aria-label="Search">
      <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
    </form>
  </div>
</nav>

<div class="container-fluid" style="margin-top: 50px;" >
    <div class="row">
        <div class="col-sm-2 col-md-2 sidebar badge-dark" style="margin:inherit;" id="sidebar" >
          <ul class="list-group text-white sidebar-list">
            <li class="list-group-item  bg-dark "><a href="admin_main.php">Welcome Admin</a></li>
            <li class="list-group-item bg-dark "><a href="manage_courses/manage_courses.php">Manage Courses</a></li>
            <li class="list-group-item bg-dark"><a href="../logout.php">Logout</a></li>  
            <li class="list-group-item bg-dark" style="height: 600px;"></li>
          </ul>
          </div> 
 


 <?php include '../connection.php';   


 if(isset( $_GET['search'])){
     $search=mysqli_real_escape_string($conn,$_GET['search']);
     $sql ="SELECT * FROM `courses` WHERE course_name LIKE '%$search%'  ";
     $res = mysqli_query($conn, $sql);
     if(mysqli_num_rows($res)>0){
        echo'  <div class="tab-pane container active" id="home">
        <div class="card-header mt-3 mr-5 bg-white text-info border-0 shadow card1" style="width: 1050px; box-shadow: 1px 1px 1px 1px #ccc"><b>Related Search</b></div>';
        
      
           while($row = mysqli_fetch_assoc($res)){
            $name = $row['course_name'];
            $desc = $row['course_desc'];
            $course_id = $row['course_id']; 
            $course_image=$row['course_image'];
            $url = "manage_courses/edit_topics.php?course_name=" . $name;
           // echo'<div class="jumbotron-fluid">
           //      <div class="result">
                //  <p class="lead">
                //  <ul> <li>
                //  <h3>&nbsp<a href="' . $url. '" class="text-dark">'  . $name.  '</a>
                //  </h3>
                //  <p>'  . $desc.  '</p></li></ul>
                //  </ div></div>'          
                  echo'<div class="rows"> 
                   <div class="card ml-5 mt-4" style="width: 18rem;">
                     <img class=card-img-top src="../'.$course_image.'" alt="Card image cap">
                     <div class="card-body">
                     <h5 class="card-title">'.$name.'
                     <a href="manage_courses/edit_topics.php?course_name='.$name.' 
                    "class="h6 text-info float-right">Open course <i class="fa fa-pencil ml-1"></i></a></h5>
                     <p class="card-text">'.$desc.'</p></div></div>
                     </div>';
           }
     }
     else{
            echo '<div class="jumbotron jumbotron-fluid">
                    <div class="container">
                         <p class="display-4">No Results Found</p>
                         <p class="lead">
                          Suggestions:<ul>
     
                                   <li>Check your spelling.</li>
                                   <li>  Try more general words.</li>
                                   <li> Try different words that mean the same thing.</li>
                                 </ul>
                                 </p>
                     </div>
                </div> ';
            
     }
 }
 ?></div></div>
