<html>
    <title>ABOUT US</title>
    <head>
        <style>
               body {
            font-family: Arial, Helvetica, sans-serif;
            margin: 0;
          }
          
          html {
            box-sizing: border-box;
          }
          
          *, *:before, *:after {
            box-sizing: inherit;
          }
          
          .column {
            float: left;
            width: 33.3%;
            margin-bottom: 16px;
            padding: 0 8px;
          }
          
          .card {
            box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
            margin: 8px;
          }
          
          .about-section {
            padding: 50px;
            text-align: center;
            background-color: #474e5d;
            color: white;
          }
          
          .container {
            padding: 0 16px;
          }
          
          .container::after, .row::after {
            content: "";
            clear: both;
            display: table;
          }
          
          .title {
            color: grey;
          }
          
          .button {
            border: none;
            outline: 0;
            display: inline-block;
            padding: 8px;
            color: white;
            background-color: #000;
            text-align: center;
            cursor: pointer;
            width: 100%;
          }
          
          .button:hover {
            background-color: #555;
          }
          
          @media screen and (max-width: 650px) {
            .column {
              width: 100%;
              display: block;
            }
          }
          </style>
    </head>
    <body>
       <div class="about-section">
  <h1>About Us</h1>
  <p>Studiera is an e-learning website. The founders of studiera created this website by keeping the interest and comfort of commmunication between learners and guides in mind. Therefore, it has features like document, chat and forum portal. 
</p>
<p>Stuidera is a graduation project of <i>Bachelor of Computer Application</i>, developed combinedly by three students namely <i>Sanskriti Saklani, Savitri and  Kusum.</i></p> 
<p>Each one of team member performed different set of task such as Sanskriti Saklani created and desiged document portal and along with that completed the final connection of all the portals. Savitri created and designed chat portal and helped Sanskriti Saklani in the process of connecting document portal with chat portal whereas Kusum created and designed forum portal and helped Sanskriti Saklani with the connection of forum with other modules.
Apart fom that Sanskriti Saklani was also responsible for creating login and registration page whereas Savitri and Kusum was responsible for analysing whole set of code and resolve minor error occcured during the whole process.</p>      
</div>

<h2 style="text-align:center">Team Members</h2>
<div class="row">
  <div class="column">
    <div class="card">
      <img src="Downloads/sans.jpg" alt="sanskriti" style="width:100%">
      <div class="container">
        <h2>SANSKRITI SAKLANI</h2>
        <p class="title">Programmer</p>
        <!-- <p>Developed document portal, login and registration page</p> -->
        <p>sans@gmail.com</p>
      
      </div>
    </div>
  </div>

  <div class="column">
    <div class="card">
      <img src="Downloads/savitri.jpg" alt="savitri" style="width:100%">
      <div class="container">
        <h2>SAVITRI</h2>
        <p class="title">Programmer</p>
        <!-- <p>Developed chat portal</p> -->
        <p>sav@gmail.com</p>
       
      </div>
    </div>
  </div>

  <div class="column">
    <div class="card">
      <img src="uploadimg/Kusum.jpg" alt="kusum" style="width:100%">
      <div class="container">
        <h2>KUSUM</h2>
        <p class="title">Programmer</p>
        <!-- <p>Developed forum</p> -->
        <p>kus@gmail.com</p>
       
      </div>
    </div>
  </div>
</div>
    </body>
</html>