<!doctype html>
<html>
<head>
<meta name="viewport" content="width=device-width",initial-scale=1.0 charset="UTF-8">
<title>Responsive Contact Us</title>




<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.3/css/fontawesome.min.css" integrity="sha384-wESLQ85D6gbsF459vf1CiZ2+rr+CsxRY0RpiF1tLlQpDnAgg6rwdsUF1+Ics2bni" crossorigin="anonymous">
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<section class="contact">
     <div class="container">
    	<div class="contactInfo">
    		<!--<div class="box">
    			<div class="icon"><i class="fa fa-map-marker" aria-hidden="true"></i></div>
    			<div class="text">
    				<h3>Address</h3>
    				<p> Swami Rama Himalayan University,<br>Jollygrant,<br>248140</p>
    			</div>
    		</div>-->
			<!-- <div class="box">
    			<div class="icon"><i class="fa fa-envelope-o" aria-hidden="true"></i></div>
    			<div class="text">
    				<h3><b>Email</b></h3>
					<p style="color:#fff">studiera7813@gmail.com</p>
    				
    			</div>
    		</div> -->
		<!--	<div class="box">
    			<div class="icon"><i class="fa fa-phone" aria-hidden="true"></i></div>
    			<div class="text">
    				<h3>Phone</h3>
    				<p> 0135-2481405</p>
					<p> 0135-2435226</p>
    			</div>
    		</div>
		
    	</div>-->

		<center>
		<div class="contactForm" style="width:500px;">
		<form action="MAILTO:studiera7813@gmail.com" method="post" enctype="text/plain">
		<h2>Send us your query via mail..!</h2>
		<div class="inputbox">Name
		<input type="text" name="Name" placeholder="Full Name" required="required">
		
		</div>
		<div class="inputbox">Email
		<input type="email" name="EMailid" placeholder="studiera7813@gmail.com" required="required">
		
		<div class="inputbox">Message
		<textarea name="msg" placeholder="Type Your Message.." required="required"></textarea>
		</div>
		<div class="inputbox">
		<input type="submit" name="" value="send" >
		</div>
		</form>
		
		
    </div>
	</center>	


    </section>
    </body>
    </html>