<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css"
        integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    
    
    <style>
    #maincontainer {
        min-height: 100vh;
    }
    #category {
        min-height:100px;
    }

    </style>
    <title>Discuss Doubts at Studiera </title>
</head>

<body>


<?php include '../connection.php';   
 include 'partials/_header.php';


 if(isset( $_GET['search'])){
     $search=mysqli_real_escape_string($conn,$_GET['search']);
     $sql ="SELECT * FROM `threads` WHERE thread_desc LIKE '%$search%' or thread_title LIKE '%$search%' ";
     $res = mysqli_query($conn, $sql);
     if(mysqli_num_rows($res)>0){
           while($row = mysqli_fetch_assoc($res)){
            $title = $row['thread_title'];
            $desc = $row['thread_desc'];
            $thread_id = $row['thread_id']; 
            $url = "thread.php?threadid=" . $thread_id;


            
            
         echo'<div class="jumbotron-fluid">
                 <div class="result">
                 <p class="lead">
                 <ul> <li>
                 <h3>&nbsp<a href="' . $url. '" class="text-dark">'  . $title.  '</a>
                 </h3>
                 <p>'  . $desc.  '</p></li></ul>
                 </ div></div>';

           }
     }
     else{
            echo '<div class="jumbotron jumbotron-fluid">
                    <div class="container">
                         <p class="display-4">No Results Found</p>
                         <p class="lead">
                          Suggestions:<ul>
     
                                   <li>Check your spelling.</li>
                                   <li>  Try more general words.</li>
                                   <li> Try different words that mean the same thing.</li>
                                 </ul>
                                 </p>
                     </div>
                </div> ';
            
     }
 }
 ?>