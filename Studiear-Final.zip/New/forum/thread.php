<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css"
        integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <style>
        #ques{
            min-height: 433px;
        }
    </style>
    <title>Discuss doubts at Studiera</title>
</head>

<body>
    <?php include '../connection.php';?>
     <?php include 'partials/_header.php';?> 
    <?php
   
    $id = $_GET['threadid'];
    $sql = "SELECT * FROM `threads` WHERE thread_id = '$id'"; 
    $result = mysqli_query($conn, $sql);
    while($row = mysqli_fetch_assoc($result)){
        $title = $row['thread_title'];
        $desc = $row['thread_desc'];
        $uid = $row['userid'];      //thread

        // Query the users table to find out the name of OP
        $sql2 = "SELECT * FROM `user` WHERE userid='$uid'";
        $result2 = mysqli_query($conn, $sql2);
        $row2 = mysqli_fetch_assoc($result2);
        $posted_by = $row2['userid'];
    }
    
    ?>

    <?php
    $showAlert = false;
    $method = $_SERVER['REQUEST_METHOD'];
    if($method=='POST'){
        //Insert into comment db
        $comment = $_POST['comment']; 
        $comment = str_replace("<", "&lt;", $comment);
        $comment = str_replace(">", "&gt;", $comment); 
        $userid = $_POST['userid']; 
        $sql = "INSERT INTO `comments` ( `comment_content`, `thread_id`, `comment_by`, `comment_time`) VALUES ('$comment', '$id', '$userid', current_timestamp())";
        $result = mysqli_query($conn, $sql);
        $showAlert = true;
        if($showAlert){
            echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
                        <strong>Success!</strong> Your comment has been added!
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                  </div>';
        } 
    }
    ?>


    <!-- Category container starts here -->
    <div class="container my-4">
        <div class="jumbotron">
            <h1 class="display-4"><?php echo $title;?></h1>
            <p class="lead">  <?php echo $desc;?></p>
            <hr class="my-4">
            <p>This is a peer to peer forum. No Spam / Advertising / Self-promote in the forums is not allowed. Do not post copyright-infringing material. Do not post “offensive” posts, links or images. Do not cross post questions. Remain respectful of other members at all times.</p>
            <p>Posted by id no: <em><?php echo $posted_by; ?></em></p>
        </div>
    </div>

     <?php 
    // if(isset($_SESSION['loggedin']) && $_SESSION['loggedin']==true){ 
       // session_start();
    echo '<div class="container">
        <h1 class="py-2">Post a Comment</h1> 
        <form action= "'. $_SERVER['REQUEST_URI'] . '" method="post"> 
            <div class="form-group">
                <label for="exampleFormControlTextarea1">Type your comment</label>
                <textarea class="form-control" id="comment" name="comment" rows="3"></textarea>
                <input type="hidden" name="userid" value="'. $_SESSION["id"]. '">
            </div>
            <button type="submit" class="btn btn-danger">Post Comment</button>
        </form> 
    </div>';
    // }
    // else{
    //     echo '
    //     <div class="container">
    //     <h1 class="py-2">Post a Comment</h1> 
    //        <p class="lead">You are not logged in. Please login to be able to post comments.</p>
    //     </div>';
    // }

    ?>


    <div class="container mb-5" id="ques">
        <h1 class="py-2">Discussions</h1>
       <?php
    $id = $_GET['threadid'];
    $sql = "SELECT * FROM `comments` WHERE thread_id= '$id'"; 
    $a=
    $result = mysqli_query($conn, $sql);
    $noResult = true;
    while($row = mysqli_fetch_assoc($result)){
        $noResult = false;
        $id = $row['comment_id'];
        $content = $row['comment_content']; 
        $comment_time = $row['comment_time']; 
        $uid = $row['comment_by'];        //thread

        $sql2 = "SELECT * FROM `user` WHERE userid = '$uid'";
        $result2 = mysqli_query($conn, $sql2);
        $row2 = mysqli_fetch_assoc($result2);
        
        $sid=$_SESSION['id'];
        $sql3 = "SELECT access FROM `user` WHERE userid = '$sid'";
        $result3 = mysqli_query($conn, $sql3);
        $row3 = mysqli_fetch_assoc($result3);
        $access=$row3['access'];



        if($access== 2){
         echo '<div class="media my-3">
            <img src="img/userdefault.jpg" width="54px" class="mr-3" alt="...">
            <div class="media-body">
               <p class="font-weight-bold my-0">'. $row2['Emailid'] .' at '. $comment_time. '</p> '. $content . '  </div>
               </div>';}


        if($access== 1){
          echo'
          <div class="row ">    

              <div class="col-md-8">    

                <table class="table ml-5 bg-white shodow pl-5 table-responsive" style=" height : 155px; overflow-y: scroll;display: inline-block; width: 940px;"> 
                <p class="ml-5"></p>
                <thead>
                  <tr>               
                    <th scope="col"></th>
                    <th scope="col"></th>
                  </tr>
                </thead>
                <tbody style="">
                <div class="media my-3">
                <div class="media-body">
                  <tr >
        
                   
                    <td> 
                    <p class="font-weight-bold my-0">'. $row2['Emailid'] .' at '. $comment_time. '</p> '. $content . '</div>  </td>
                    <td><a class=" no-gutters text-danger" href="partials/comment_delete.php?comment_id='. $row['comment_id'].' " 
                     style="text-decoration: none;">Delete<i class="fa fa-trash-o ml-2" aria-hidden="true"></a></td>

                  </tr>
                  </div>
                </tbody>
              </table>
              </div></div>
          
          ';

        }}

        
        // echo "this is good";
        // echo var_dump($noResult);
        if($noResult){
            echo '<div class="jumbotron jumbotron-fluid">
                    <div class="container">
                        <p class="display-4">No Comments Found</p>
                        <p class="lead"> Be the first person to comment</p>
                    </div>
                 </div> ';
        }
    
    ?> 
    
   </div>

    <!-- <?php include 'partials/_footer.php';?> -->
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"
        integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous">
    </script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"
        integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous">
    </script>
</body>

</html>