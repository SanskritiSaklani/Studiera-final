<?php
 session_start();
echo'<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
<div class="container-fluid">
  <a class="navbar-brand" href="//index.php">Studiera  </a>
  <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>';
  //<div class="collapse navbar-collapse" id="navbarSupportedContent">'
    // <ul class="navbar-nav me-auto mb-2 mb-lg-0">
      
    //   <li class="nav-item dropdown">
    //     <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopups="true" aria-expanded="false">
    //      Courses
    //     </a>
    //     <ul class="dropdown-menu" aria-labelledby="navbarDropdown">';

  //          $sql="SELECT course_name, course_id FROM `courses` LIMIT 3";
  //          $result = mysqli_query($conn, $sql);   
  //          while($row = mysqli_fetch_assoc($result))
  //         {
  //         echo '<li><a class="dropdown-item" href="threadlist.php?catid=' .$row['course_id']. '">' .$row['course_name']. '</a></li>';
  //         }
  //     echo  '</ul>
  //     </li>
  //   </ul>

  // <div class="row mx-2">';

   

   echo '<form class="d-flex" method="get" action="search2.php">
         <input class="form-control me-2" name ="search" type="search" action = "search.php" placeholder="Search" aria-label="Search" required/>
         <button class="btn btn-outline-danger" type="submit"> Search</button>
       </form>';

 echo'</div>
</div>
</nav>';
//can be used in place of two first lineof  seach seach button code 
//<form class="form-inline my-2 my-lg-0" method="get" action="search.php">
//<input class="form-control mr-sm-2" name="search" type="search" actiion="search.php" placeholder="Search" aria-label="Search">
  //  <button class="btn btn-success my-2 my-sm-0" type="submit">Search</button>

//  include 'partials/_loginModal.php';
// include 'partials/_signupModal.php';
// if(isset($_GET['signupsuccess']) && $_GET['signupsuccess'] == "true")
// {
//   echo '<div class="alert alert-danger alert-dismissible fade show my-0" role="alert">
//   <strong>Success!</strong> You can now login
//   <button type="button" class="close" data-dismiss="alert" aria-label="Close">
//     <span aria-hidden="true">&times;</span>
//   </button>
// </div>';

// }
?>