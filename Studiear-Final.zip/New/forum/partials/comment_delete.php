<?php 
 include '../../connection.php';

       		$id=$_GET['comment_id'];
			$sql="SELECT thread_id from comments where comment_id='$id'";
			$res=mysqli_query($conn,$sql);
			$row=mysqli_fetch_assoc($res);
            $thread_id=$row['thread_id'];
			//echo $thread_id;

       		$q="DELETE from comments where comment_id='$id'";
			$result=mysqli_query($conn,$q);
			if ($result) {
				header("location:../thread.php?threadid=$thread_id");
			}


 ?>