<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Log-in Studiera</title>
</head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="css/style.css">
<style>
    /* CSS  Reset */
    body {
        font-family: cursive;
        margin: 0px;
        padding: 0px;
        background: url('downloads/book2.jpg');
        

    }
    .left img{
    
        width: 100px;

    }
    .left div{
        text-align: center;
        color: rgb(233, 200, 161);
        font-size: 23px;
        line-height: 19px;
       
    }

    .left {
        /* border: 2px solid red; */
        display: inline-block;
        position: absolute;
        top: 25px;
        left: 50px;

    }

    .mid {
        /* border: 5px solid rgb(14, 4, 48); */
        display: block;
        width: 20%;
        margin: 50px auto;
        font-size: 20px;

    }

    .right {
        /* border: 5px solid rgb(23, 185, 36); */
        display: inline-block;
        position: absolute;
        right: 34px;
        top: 25px;
        
    }

    .navbarr {
        display: inline-block;
    }

    .navbarr li {
        display: inline-block;
        font-style: 20px;
    }

    .navbarr li a {
        color: rgb(233, 200, 161);
        text-decoration-line: none;
        padding: 30px 30px;
    }

    .navbarr li a:hover,
    .navbarr li a.active {
        color: rgb(225, 238, 111);
        text-decoration-line: underline;

    }

    .btn{
        background-color: rgb(131, 36, 36);
        color:rgb(235, 192, 141);
        margin:0px 9px;
        padding:4px 14px;
        border:2px solid rgb(248, 182, 101);
        border-radius: 10px;
        font-size: 20px;
        cursor:pointer;
        font-family: cursive;
       

    }
    .btnn{
        width:30%;
    }
    .btn:hover{
        background-color: rgb(90, 53, 7);
    }

    .container{
        color:burlywood;
        border:2px solid rgb(230, 112, 112);
        border-radius: 20px;
        padding: 60px;
        width: 35%;
        margin:70px auto;
        display: block;
            }
     .form-groups input{
         text-align: center;
         display: block;
         margin:25px;
         padding:2px;
         border:2px solid burlywood;
         font-size: 20px;
         border-radius: 20px;
         font-family: cursive;
         width:85%;


         margin-bottom: 20px !important;
	     padding: 4px !important;
	     width: 220px !important;
	     height: 32px !important;
	     border: none !important;
    	outline: none !important;
    	border-bottom: 1px solid #aaa !important;
    	font-weight: 400px !important;
    	font-size: 15px !important;
    	transition: 0.5s ease-in !important;


     }
     .container h1,h3{
         text-align: center;
     }
     .container button{
         display: block;
         width:60%;
         margin:20px auto;
     }

     .container a{
        display: block;
        width:25%;
        margin:20px auto;
    }

     .log{ background-color: rgb(131, 36, 36);
        color:rgb(235, 192, 141);
        margin:0px 9px;
        padding:4px 14px;
        border:2px solid rgb(248, 182, 101);
        border-radius: 10px;
        font-size: 20px;
        cursor:pointer;
        font-family: cursive;}
</style>

<body>
    <header class="header">
        <!-- leftbox for logo -->
        <div class=left>
          <img src="downloads/book1.jpeg" alt="">
            <div>StudiEra</div>

        </div>

        <!-- midbox for navigation -->
        <div class=mid>
            <ul class="navbarr">
                <li><a href="#" class=active>Home</a></li>
                <!-- <li><a href="#"></a></li> -->
                <li><a href="aboutus.php">About Us</a></li>
               <!-- <li><a href="#">Help</a></li> -->
            </ul>


        </div>

        <!-- rightbox for buttons -->
        <form action="contactus.php">
        <div class=right >
            <button class="btn">Contact-Us </button>
            <!-- <button class="btn">Email-Us</button> -->
        </div>
     </form>
    </header>
    <div class="container"> 
        <h1>Welcome to Studiera..!!</h1>
        <center><h4>Log-in to your account </h4></center>
        

    <div class=form-groups action="login.php" >  

    <form method="POST"  action="login.php">
        
    <center> <input type="text" name="Emailid" placeholder="Enter your email-id " required/></center>
       
    <center> <input type="password" name="Password" placeholder="Enter your Password" required/></center>
       
    
             <center><input id="Button" type="submit" name="submit" value="Login" class="btn"></center>
        <br>

    </form>
    </div>
        <form action="signup.php">
        <button class="btn">New User Click Here..!!</button>
        </form>

        
   
    </div>

    <center>
			<?php
				session_start();
				if(isset($_SESSION['msg']))
                {   echo $_SESSION['msg'];
					unset($_SESSION['msg']);
				}
			?>
	</center>
    
</body>
</html>