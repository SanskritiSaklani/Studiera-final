<?php
//connecting to the database
	include '../connection.php';
	session_start();
	$course_name=$_POST['course_name'];
	$msg=$_POST['text'];


	$sql = "SELECT roomid FROM `rooms` WHERE course_name = '$course_name'";
	$result = mysqli_query($conn, $sql);
	$row = mysqli_fetch_array($result);
	$roomid=$row['roomid'];
	
	
	$sq=mysqli_query($conn,"select * from `user` where userid='".$_SESSION['id']."'");
	$srow=mysqli_fetch_array($sq);	
	$Name=$srow['Name'];
	$_SESSION['Name'] = $Name;

	$sql="INSERT INTO `new`.`msgs` (`roomid`,`msg` ,`course_name` ,`Name`,`userid` ,`stime`)VALUES ( '$roomid','$msg', '$course_name', '$Name','".$_SESSION['id']."',CURRENT_TIMESTAMP)";
    mysqli_query($conn,$sql);
    mysqli_close($conn);




?>