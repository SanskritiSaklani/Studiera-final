<?php
session_start();
$course_name = $_POST['course_name'];

include '../connection.php';

$sq=mysqli_query($conn,"select * from `user` where userid='".$_SESSION['id']."'");
$srow=mysqli_fetch_array($sq);	
$Name=$srow['Name'];
$_SESSION['Name'] = $Name;

// $query = "SELECT * from `msgs` left join `user` on  msgs.Name = user.Name where msgs.userid=user.userid order by chat_date asc";
// $r=mysqli_query($conn, $query);


$sql = "SELECT msg,Name, stime FROM `msgs` WHERE course_name = '$course_name'";
$res = "";
$result = mysqli_query($conn, $sql);
if(mysqli_num_rows($result) > 0)
{

    while($row = mysqli_fetch_assoc($result))
    {
     $res = $res . '<div class="container">';
     $res = $res . $row['Name'];
    //  $res = $res . $_SESSION['Name'];
     $res = $res . " says <p>".$row['msg'];
     $res = $res . '</p> <span class="time-right">' . $row["stime"] . '</span></div>';
    }
}
echo $res;

?>