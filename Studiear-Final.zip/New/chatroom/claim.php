<?php
//getting the value of post parameter
$course_name = $_GET['course_name'];

//connecting to the database
session_start();
include '../connection.php';


//check if room already exists or not
$sql = "SELECT * FROM `rooms` WHERE course_name = '$course_name'";
$result = mysqli_query($conn, $sql);
if($result)
{
if (mysqli_num_rows($result) == 0)
{ $sql = "INSERT INTO `rooms` (`course_name` ,`stime`) VALUES ( '$course_name',CURRENT_TIMESTAMP);";
	if (mysqli_query($conn, $sql)){
	echo '<script language="javascript">';	
	echo 'window.location="http://localhost/New/chatroom/rooms.php?course_name='. $course_name. '";';
	echo '</script>';
	}
}
else{
	echo '<script language="javascript">';	
	echo 'window.location="http://localhost/New/chatroom/rooms.php?course_name='. $course_name. '";';
	echo '</script>';
}

}
else
 {
 	echo "error: ".mysqli_error($conn);
}	

?>